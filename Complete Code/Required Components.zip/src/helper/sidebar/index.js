export const sideBarMenu = [
  {
    title: "Getting Started",
    link: "/GettingStarted",
    child: [
      {
        title: "What is ciPARTHENON",
        link: "/CIPARTHENON",
        child:[]
      },
    ],
  },


  {
    title: "Accessing your Dashboards",
    link: "/AccessingDashboards",
    child: [

      {
        title: "Organize your dashboards",
        link: "/OrganizeYourDashboards",
        child: [
          {
            title: "Dasboard Properties",
            link: "/DashboardProperties",
            child: []
          },
        ],
      },
    
  
      {
       title: "Rebind your dashboards",
       link: "/RebindYourDashboards",
       child:[]
      },
    
      {
       title: "Visualize and Share your dashboards",
       link: "/VisualizeAndShareYourDashboards",
       child: []
      },
    ],
  },
      {
        title: "Preparing your Data",
        link: "/PreparingYourData",
        child: [
    
          {
            title: "Before Importing the data",
            link: "/BeforeImportingTheData",
            child: []
              
          },
        
      
          {
           title: "My Data",
           link: "/MyData",
           child:[
             {
               title: "Data Preview",
               link: "/DataPreview",
               child:[]
             },
             {
               title: "Data Properties",
               link: "/DataProperties",
               child:[]
             }
            ],
          },
          {
            title: "Create Data",
            link: "/CreateData",
            child:[
              {
                title: "Steps need to follow",
                link: "/stepsToFollow",
                child:[]
              },
            ],
          },
          {
            title: "Create View",
            link: "/CreateView",
            child:[]
          },
          {
            title: "Merge Data",
            link: "/MergeData",
            child:[
              {
                title: "Steps to follow",
                link: "/StepsToFollow",
                child:[]
              },
            ],
          },
          {
            title: "Data refresh methods",
            link: "/DataRefreshMethods",
            child:[]
         },
         {
           title: "Data Transformation",
           link: "/DataTransformation",
           child:[
             {
               title: "Aggregated Column",
               link:  "/AggregatedColumn",
               child:[]
             },
             {
               title: "Calculated Column",
               link: "/CalculatedColumn",
               child:[]
             },
             {
               title: "Text splitter",
               link: "/TextSplitter",
               child:[]
             },
             {
               title: "Filer",
               link: "/Filter",
               child:[]
             },
             {
               title: "Find and replace",
               link: "/FindAndReplace",
               child:[]
             },
             {
               title: "Grouping",
               link: "/Grouping",
               child:[]
             },
             {
               title: "Normalize" ,
               link: "/Normalize" ,
               child:[]
             },
             {
               title: "PivotData",
               link: "/PivotData",
               child:[]
             },
             {
               title: "Standardize",
               link: "/Standardize",
               child:[]
             },
             {
               title: "Update",
               link: "/Update",
               child:[]
             },
             {
               title: "UnpivotData",
               link: "/UnpivotData",
               child:[]
             },
           ],
          
          },
           {
             title: "My Connections",
             link: "/MyConnections",
             child:[
               {
                 title: "Connection Properties",
                 link: "/ConnectionProperties",
                 child:[]
               },
               {
                 title: "Connection Broker",
                 link: "/ConnectionBroker",
                 child:[]
               }
              ],
            },
              {
                title: "Data Fusion",
                link: "/DataFusion",
                child:[]
              },
              {
                title: "Data Stream",
                link: "/DataStream",
                child:[]
              },
            

            
          

            
           
            

           
         
        ],
     }, 
     {
       title: "Building A Dashboard",
       link: "/BuildingADashboard",
       child:[

        {
          title: "Create your first Dashboard",
          link: "/CreateYourFirstDashboard",
          child: []
        },
        {
          title: " Dashboard Binders",
          link: "/DashboardBinders",
          child: []
        },
        {
          title: "Filter your Widgets",
          link: "/FilterYourWidgets",
          child: [
            {
              title: "Global Filter",
              link: "/GlobalFilter",
              child: []
            },
            {
              title: "Using Data Selectors",
              link: "/UsingDataSelectors",
              child:[]
            },
            {
              title:"Using Inputs",
              link: "/UsingInputs",
              child:[
                {
                  title: "Using Numeric Inputs",
                  link: "/UsingNumericInputs",
                  child: []
                },
                {
                  title: "Using Text Inputs",
                  link: "/UsingTextInputs",
                  child:[]
                },

              ],
              

            },
            {
              title: "Using Lists",
              link: "/UsingLists",
              child:[
                {
                  title: "Using Formula",
                  link: "/UsingFormula",
                  child:[]
                },
                {
                  title: "Using Widgets",
                  link: "/UsingWidgets",
                  child:[]
                }
              ],
            },
            {
              title: "Working with widgets",
              link: "/WorkingWithWidgets",
              child: [

              ]
            }
          
          ]
        }
       ]
     }  
    
];
     
      
    
  
    

export const stylSelected = {
  color: "red",
};

    
